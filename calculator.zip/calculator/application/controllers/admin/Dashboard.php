<?php

class Dashboard extends CI_Controller {

    public function __construct() {
        parent::__construct();
        $this->load->library('session');
        $this->load->helper('url');
        $this->load->model('loginmodel');
    }


    public function index() {
        echo 'Hello';
        print_r( $this->session->userdata() ); exit;
        if ($this->session->userdata('user_id'))
            redirect(base_url('dashboard'));
            $this->load->view('templates/head', $data);
            $this->load->view('templates/navbar', $data);
            $this->load->view('admin/dashboard',$data);
            $this->load->view('templates/footer', $data);
    }

    public function logout() {
        $this->session->unset_userdata('user_id');
        redirect(base_url('login'));
    }

}

?>